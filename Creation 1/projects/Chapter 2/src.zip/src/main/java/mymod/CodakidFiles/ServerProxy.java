package mymod.CodakidFiles;

import mymod.CommonProxy;

public class ServerProxy extends CommonProxy {

}